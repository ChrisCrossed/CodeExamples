using UnityEngine;
using System.Collections;

namespace ProGrids
{
	public static class k
	{
		public const string ProGridsUpgradeURL = "http://u3d.as/content/six-by-seven-studio/pro-grids/3ov";
		public const string SnapValueEditorPref = "pgSnapValue";
		public const string SnapUnitEditorPref = "pgSnapUnit";
		public const string UseAxisConstraints = "pgUseAxisConstraints";
	}
}