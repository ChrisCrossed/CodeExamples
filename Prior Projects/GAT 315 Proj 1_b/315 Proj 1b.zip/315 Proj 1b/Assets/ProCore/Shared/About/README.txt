Place About folder in a Shared folder - eg, ProCore/Shared

Update the ABOUT_ROOT const with this path.

On Asset import, AboutWindow will scan for pc_AboutEntry_YOUR_PRODUCT.txt files and display a popup with the parsed information.